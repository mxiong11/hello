package servlet;

import entities.Conversion;
import entities.User;
import service.ConversionService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	ConversionService conversionService = new ConversionService();
	UserService userService = new UserService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String browser = "unknow";

		String agent = req.getHeader("user-agent");

		if (agent.contains("Chrome")) {
			System.out.println("agent = " + agent);
			browser = "Chrome";
		} else if (agent.contains("Firefox")) {
			System.out.println("agent = " + agent);
			browser = "Firefox";
		}

		User user = new User(username, password);

		User u = userService.select(user);

		if (u != null) {
			HttpSession session = req.getSession();
			session.setAttribute("user", u);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			User u2 = new User();
			u2.setId(u.getId());
			u2.setLastLoginTime(u.getLoginTime());
			u2.setLoginTime(sdf.format(new Date()));
			u2.setCount((u.getCount() + 1));
			System.out.println("(u.getCount()+1) = " + (u.getCount() + 1));
			int update = userService.update(u2);

			List<Conversion> conversionList = conversionService.select(u.getId());

			req.setAttribute("browser", browser);
			req.setAttribute("conversionList", conversionList);
			req.getRequestDispatcher("/index.jsp").forward(req, resp);
		} else {
			req.setAttribute("loginMsg", "wrong username or password");
			req.getRequestDispatcher("/login.jsp").forward(req, resp);
		}

	}

}
