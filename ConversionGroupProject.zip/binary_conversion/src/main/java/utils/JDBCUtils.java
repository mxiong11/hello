package utils;

import java.sql.*;

public class JDBCUtils {

	static Connection connection = null;

	/**
	 * get
	 */
	static public Connection getConnectMysql() {
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
            
			//String dbname="binary_conversion";
			//String url = "jdbc:mysql://localhost:3306/" + dbname;
			String url = "jdbc:mysql://localhost/binary_conversion?serverTimezone=GMT%2B8";
			String username="root";
			String password="password";

			connection = DriverManager.getConnection(url,username,password);
			System.out.println("Successfully connect to the database! ! !");
			return connection;

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load JDBC driver class");
		} catch (SQLException e) {
			System.out.println("Failed to create database connection");
		}
		return null;
	}

}
