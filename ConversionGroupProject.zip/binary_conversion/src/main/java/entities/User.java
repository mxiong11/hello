package entities;


import java.util.Date;


public class User {
 
    private Integer id;
   
    private String username;
  
    private String password;
   
    private String loginTime;
   
    private String email;
   
    private Integer count;


    private String lastLoginTime;


    public User() {
        this.id = id;
        this.username = username;
        this.password = password;
        this.loginTime = loginTime;
        this.email = email;
        this.count = count;
    }


    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(String username, String password, String email, String loginTime, String lastLoginTime) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.loginTime = loginTime;
        this.lastLoginTime = lastLoginTime;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", loginTime=" + loginTime +
                ", email='" + email + '\'' +
                ", count=" + count +
                ", lastLoginTime=" + lastLoginTime +
                '}';
    }


}
