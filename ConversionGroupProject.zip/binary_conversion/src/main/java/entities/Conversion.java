package entities;

import java.util.Date;

public class Conversion {

	private Integer id;

	private String beforeConversion;

	private String afterConversion;

	private Integer userId;

	private String createTime;

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Conversion() {
	}

	public Conversion(Integer id, String beforeConversion, String afterConversion, Integer userId) {
		this.id = id;
		this.beforeConversion = beforeConversion;
		this.afterConversion = afterConversion;
		this.userId = userId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBeforeConversion() {
		return beforeConversion;
	}

	public void setBeforeConversion(String beforeConversion) {
		this.beforeConversion = beforeConversion;
	}

	public String getAfterConversion() {
		return afterConversion;
	}

	public void setAfterConversion(String afterConversion) {
		this.afterConversion = afterConversion;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
}
