package service;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.User;
import utils.JDBCUtils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserService {
	/**
	 * get
	 */
	private Connection connection = JDBCUtils.getConnectMysql();

	/**
	 * insert
	 *
	 * @param user
	 * @return
	 */
	public int insert(User user) {
		System.out.println("user = " + user);

		String sql = "insert into user(username,password,email,count,login_time,last_login_time) values('"
				+ user.getUsername() + "','" + user.getPassword() + "','" + user.getEmail() + "',0,'"
				+ user.getLoginTime() + "','" + user.getLastLoginTime() + "')";

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			int i = statement.executeUpdate(sql);
			System.out.println("The data is inserted successfully, the number of data items affected = " + i);

			return i;

		} catch (SQLException e) {

			System.out.println("Failed to insert into the database," + e.getMessage());
		} finally {

		}

		return 0;
	}

	/**
	 * select
	 * 
	 * @param user
	 * @return
	 */
	public User select(User user) {

		Connection connection = JDBCUtils.getConnectMysql();

		String sql = "select * from user where username = '" + user.getUsername() + "' and  password = '"
				+ user.getPassword() + "'";

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			resultSet = statement.executeQuery(sql);

			User u = null;
			while (resultSet.next() == true) {
				/*
				 * System.out.println("resultSet.getString(\"id\") = " +
				 * resultSet.getString("id"));
				 * System.out.println("resultSet.getString(\"username\") = " +
				 * resultSet.getString("username"));
				 * System.out.println("resultSet.getString(\"password\") = " +
				 * resultSet.getString("password"));
				 * System.out.println("resultSet.getString(\"email\") = " +
				 * resultSet.getString("email")); System.out.
				 * println("Integer.parseInt(resultSet.getString(\"count\")) = "
				 * + Integer.parseInt(resultSet.getString("count")));
				 */

				u = new User();
				u.setId(Integer.parseInt(resultSet.getString("id")));
				u.setUsername(resultSet.getString("username"));
				u.setPassword(resultSet.getString("password"));
				u.setEmail(resultSet.getString("email"));
				u.setCount(Integer.parseInt(resultSet.getString("count")));
				u.setLoginTime(resultSet.getString("login_time"));
				u.setLastLoginTime(resultSet.getString("last_login_time"));
			}

			return u;
		} catch (SQLException e) {
			System.out.println("Failed to query the database");
		}

		return null;
	}

	/**
	 * update
	 * 
	 * @param user
	 * @return
	 */
	public int update(User user) {

		String sql = "update user set login_time = '" + user.getLoginTime() + "', last_login_time = '"
				+ user.getLastLoginTime() + "', count = '" + user.getCount() + "' where id = '" + user.getId() + "'";
		// String sql = "update user set login_time = "+ user.getLoginTime() +",
		// last_login_time = "+ user.getLastLoginTime() + ", count = " +
		// user.getCount() +" where id = "+ user.getId();

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			int i = statement.executeUpdate(sql);
			System.out.println("Data update is successful, the number of data items affected = " + i);
			return i;

		} catch (SQLException e) {

			System.out.println("Failed to update the database," + e.getMessage());
		}

		return 0;
	}

}
