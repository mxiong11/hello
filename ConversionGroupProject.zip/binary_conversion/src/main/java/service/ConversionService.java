package service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.Conversion;
import utils.JDBCUtils;

public class ConversionService {
	/**
	 * get
	 */
	private Connection connection = JDBCUtils.getConnectMysql();

	/**
	 * binary to decimal
	 * 
	 * @param bin
	 */
	public String binToTen(String bin) {
		/**
		 * //十进制转成十bai六进制： Integer.toHexString(int i) //十进制转成八进制
		 * Integer.toOctalString(int i) //十进制转成二进制 Integer.toBinaryString(int i)
		 * //十六进制转成十进制 Integer.valueOf("FFFF",16).toString() //八进制转成十进制
		 * Integer.valueOf("876",8).toString() //二进制转十进制
		 * Integer.valueOf("0101",2).toString()
		 */

		int binaryNumber = Integer.parseInt(bin);

		int decimal = 0;
		int p = 0;
		while (true) {
			if (binaryNumber == 0) {
				break;
			} else {
				int temp = binaryNumber % 10;
				decimal += temp * Math.pow(2, p);
				binaryNumber = binaryNumber / 10;
				p++;
			}
		}
		String d = Integer.toString(decimal);
		return d;
	}

	public static void main(String args[]) {
		ConversionService obj = new ConversionService();
		System.out.println("110 --> " + obj.binToTen("110"));
		System.out.println("1101 --> " + obj.binToTen("1101"));
		System.out.println("100 --> " + obj.binToTen("100"));
		System.out.println("110111 --> " + obj.binToTen("110111"));
	}

	/**
	 * binary to octal
	 * 
	 * @param bin
	 */
	public String binToEight(String bin) {
		String dec = binToTen(bin);
		int decimal = Integer.parseInt(dec);
		int rem; // declaring variable to store remainder
		String octalNum = ""; // declareing variable to store octal
		// declaring array of octal numbers
		char octalchars[] = { '0', '1', '2', '3', '4', '5', '6', '7' };
		// writing logic of decimal to octal conversion
		while (decimal > 0) {
			rem = decimal % 8;
			octalNum = octalchars[rem] + octalNum;
			decimal = decimal / 8;
		}
		return octalNum;
	}
	
	
	
	public static String hexTodecimal(String hex) {

		String digits = "0123456789ABCDEF";
		hex = hex.toUpperCase();
		int value = 0;
		for (int i = 0; i < hex.length(); i++) {
			char y = hex.charAt(i);
			int z = digits.indexOf(y);
			value = 16 * value + z;
		}
		String s = String.valueOf(value);
		return s;
	}

	public static String hexTobinary(String hex) {

		String decimal = hexTodecimal(hex);

		int result = Integer.parseInt(decimal);

		int remainder;
		String binary = "";
		while (result != 0) {
			remainder = result % 2;
			result /= 2;
			binary = remainder + binary;
		}
		return binary;
	}
	
	
	
	
	
	
	
	
	
	public static String DecimaltoOctal(String decimal){
		int decimal2=Integer.parseInt(decimal);
	     int rem; //declaring variable to store remainder  
	     String octal=""; //declareing variable to store octal  
	     //declaring array of octal numbers  
	     char octalchars[]={'0','1','2','3','4','5','6','7'};  
	     //writing logic of decimal to octal conversion   
	     while(decimal2>0)  
	     {  
	        rem=decimal2%8;   
	        octal=octalchars[rem]+octal;   
	        decimal2=decimal2/8;  
	     }  
	     return octal;  
	 } 
	 public static String DecimaltoHex(String decimal) {
		 int decimal2=Integer.parseInt(decimal);
	  int var;
	  String hex="";
	     char hexchar[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	     while(decimal2>0) 
	     {
	      var=decimal2%16;
	      hex=hexchar[var]+hex;
	      decimal2=decimal2/16;
	     }
	     return hex;
	 }
	
	
	
	
	
	 
	 
	 
	 public static String  hextodecimal(String hex2){
	        int outcome = 0;
	        for(int i = 0; i < hex2.length(); i++){
	            char hexChar = hex2.charAt(i);
	            outcome = outcome * 16 + charToDecimal(hexChar);
	        }
	        String outcome2=String.valueOf(outcome);
	        return outcome2;
	    }
	  
	    public static int charToDecimal(char c){
	        if(c >= 'A' && c <= 'F')
	            return 10 + c - 'A';
	        else
	            return c - '0';
	    }
	
	    
	    public static String  hextooctal(String hex2){
	    	String b=hextodecimal(hex2);
	    	int c=Integer.parseInt(b);
	    	String a=Integer.toOctalString(c);
	    	return a;
	    	
	    }
	    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/**
	 * userInsert
	 *
	 * @param conversion
	 * @return
	 */
	public int insert(Conversion conversion) {

		String sql = "insert into conversion(before_conversion,after_conversion,user_id,create_time) values('"
				+ conversion.getBeforeConversion() + "','" + conversion.getAfterConversion() + "','"
				+ conversion.getUserId() + "','" + conversion.getCreateTime() + "')";

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			int i = statement.executeUpdate(sql);
			System.out.println("The data is inserted successfully, the number of data items affected = " + i);

			return i;

		} catch (SQLException e) {

			System.out.println("Failed to insert into the database," + e.getMessage());
		} finally {

		}

		return 0;
	}

	/**
	 * user update
	 * 
	 * @param conversion
	 * @return
	 */
	public int update(Conversion conversion) {

		String sql = "update conversion set before_conversion = '" + conversion.getBeforeConversion()
				+ "', after_conversion = '" + conversion.getAfterConversion() + "' where user_id = '"
				+ conversion.getUserId() + "'";

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			int i = statement.executeUpdate(sql);
			System.out.println("Data update is successful, the number of data items affected = " + i);
			return i;

		} catch (SQLException e) {

			System.out.println("Failed to update the database," + e.getMessage());
		}

		return 0;
	}

	/**
	 * select
	 * 
	 * @param userId
	 * @return
	 */
	public List<Conversion> select(Integer userId) {

		String sql = "select * from conversion where user_id = '" + userId + "' order by create_time DESC limit 0,5";

		Statement statement = null;

		ResultSet resultSet = null;
		try {

			statement = connection.createStatement();

			resultSet = statement.executeQuery(sql);

			List<Conversion> conversionList = new ArrayList<>();
			while (resultSet.next() == true) {
				Conversion c = new Conversion();
				c.setId(Integer.parseInt(resultSet.getString("id")));
				c.setBeforeConversion(resultSet.getString("before_conversion"));
				c.setAfterConversion(resultSet.getString("after_conversion"));
				c.setUserId(Integer.parseInt(resultSet.getString("user_id")));
				c.setCreateTime(resultSet.getString("create_time"));
				conversionList.add(c);
			}

			return conversionList;
		} catch (SQLException e) {
			System.out.println("Failed to query the database");
		}

		return null;
	}

}
